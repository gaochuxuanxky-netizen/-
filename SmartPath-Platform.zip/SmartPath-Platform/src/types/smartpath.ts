export type GoalType = 'internet-job' | 'postgraduate-exam' | 'research-track' | 'general-growth';

export interface UserProfile {
  name: string;
  school: string;
  major: string;
  grade: string;
  target: GoalType;
}

export interface Course {
  id: string;
  name: string;
  credit: number;
  score: number;
  category: string;
}

export interface Project {
  id: string;
  name: string;
  role: string;
  type: string;
  description: string;
  tags: string[];
  impact: number;
}

export interface Achievement {
  id: string;
  name: string;
  level: string;
  date: string;
  description: string;
}

export interface SmartPathData {
  profile: UserProfile;
  courses: Course[];
  projects: Project[];
  achievements: Achievement[];
}

export interface AbilityScore {
  academic: number;
  practice: number;
  innovation: number;
  honor: number;
  overall: number;
}

export interface Suggestion {
  title: string;
  detail: string;
  priority: '高' | '中' | '低';
}
