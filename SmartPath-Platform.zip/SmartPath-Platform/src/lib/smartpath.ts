import { Achievement, AbilityScore, Course, GoalType, Project, SmartPathData, Suggestion } from '../types/smartpath';

export const defaultData: SmartPathData = {
  profile: {
    name: '张同学',
    school: '示例大学',
    major: '计算机科学与技术',
    grade: '大三',
    target: 'internet-job',
  },
  courses: [
    { id: 'c1', name: '数据结构', credit: 4, score: 88, category: '专业核心' },
    { id: 'c2', name: '数据库系统', credit: 3, score: 91, category: '专业核心' },
    { id: 'c3', name: '软件工程', credit: 3, score: 86, category: '工程实践' },
  ],
  projects: [
    {
      id: 'p1',
      name: 'SmartPath 成长规划系统',
      role: '产品与前端开发',
      type: '课程项目',
      description: '面向大学生的个人发展数据管理、能力评估与简历生成平台。',
      tags: ['React', '数据分析', '规划系统'],
      impact: 4,
    },
  ],
  achievements: [
    {
      id: 'a1',
      name: '校级创新项目立项',
      level: '校级',
      date: '2025-10',
      description: '参与大学生创新训练计划，完成系统原型设计。',
    },
  ],
};

export const goalLabels: Record<GoalType, string> = {
  'internet-job': '互联网公司就业',
  'postgraduate-exam': '研究生考试',
  'research-track': '科研创新方向',
  'general-growth': '综合能力提升',
};

export function calculateGpa(courses: Course[]): number {
  const totalCredits = courses.reduce((sum, course) => sum + Number(course.credit || 0), 0);
  if (!totalCredits) return 0;

  const weighted = courses.reduce((sum, course) => {
    const score = Number(course.score || 0);
    const point = score >= 60 ? Math.min(4, Math.max(1, (score - 50) / 10)) : 0;
    return sum + point * Number(course.credit || 0);
  }, 0);

  return Number((weighted / totalCredits).toFixed(2));
}

export function averageScore(courses: Course[]): number {
  if (!courses.length) return 0;
  return Math.round(courses.reduce((sum, course) => sum + Number(course.score || 0), 0) / courses.length);
}

export function evaluateAbilities(courses: Course[], projects: Project[], achievements: Achievement[]): AbilityScore {
  const academic = Math.min(100, Math.round(averageScore(courses) * 0.9 + calculateGpa(courses) * 6));
  const practice = Math.min(100, projects.length * 22 + projects.reduce((sum, project) => sum + project.impact * 4, 0));
  const innovation = Math.min(100, projects.filter((project) => project.type.includes('科研') || project.type.includes('创新')).length * 28 + achievements.length * 12);
  const honor = Math.min(100, achievements.length * 25 + achievements.filter((item) => ['国家级', '省级'].includes(item.level)).length * 18);
  const overall = Math.round(academic * 0.35 + practice * 0.3 + innovation * 0.2 + honor * 0.15);

  return { academic, practice, innovation, honor, overall };
}

export function generateSuggestions(data: SmartPathData): Suggestion[] {
  const abilities = evaluateAbilities(data.courses, data.projects, data.achievements);
  const suggestions: Suggestion[] = [];

  if (abilities.academic < 82) {
    suggestions.push({
      title: '提升学业表现与核心课程成绩',
      detail: '建议优先复盘专业核心课程，建立错题与知识点清单，将 GPA 稳定提升到目标方向要求区间。',
      priority: data.profile.target === 'postgraduate-exam' ? '高' : '中',
    });
  }

  if (abilities.practice < 70) {
    suggestions.push({
      title: '补充项目与实习实践经历',
      detail: '建议选择 1-2 个可展示成果的实践项目，明确个人角色、技术栈、量化结果，并沉淀作品集。',
      priority: data.profile.target === 'internet-job' ? '高' : '中',
    });
  }

  if (abilities.innovation < 60 && data.profile.target !== 'internet-job') {
    suggestions.push({
      title: '增强科研与竞赛创新能力',
      detail: '可参与导师课题、学科竞赛或大学生创新训练项目，积累论文、专利、竞赛作品等证明材料。',
      priority: data.profile.target === 'research-track' ? '高' : '中',
    });
  }

  if (abilities.honor < 55) {
    suggestions.push({
      title: '系统整理荣誉奖项与综合素质材料',
      detail: '建议按国家级、省级、校级、院级分类管理证书，补充获奖时间、贡献说明和证明文件。',
      priority: '低',
    });
  }

  if (!suggestions.length) {
    suggestions.push({
      title: '当前能力结构较均衡',
      detail: '建议继续保持数据记录习惯，并围绕目标方向打造 1 个高质量代表性项目或成果。',
      priority: '中',
    });
  }

  return suggestions;
}

export function buildResume(data: SmartPathData): string {
  const gpa = calculateGpa(data.courses);
  const avg = averageScore(data.courses);
  const courseText = data.courses.map((course) => `${course.name}（${course.score} 分 / ${course.credit} 学分）`).join('、');
  const projectText = data.projects.map((project) => `- ${project.name}｜${project.role}｜${project.type}\n  ${project.description}\n  标签：${project.tags.join('、') || '暂无'}`).join('\n');
  const achievementText = data.achievements.map((item) => `- ${item.name}｜${item.level}｜${item.date}\n  ${item.description}`).join('\n');

  return `${data.profile.name}｜${data.profile.school}｜${data.profile.major}｜${data.profile.grade}\n目标方向：${goalLabels[data.profile.target]}\n\n学业表现\nGPA：${gpa} / 4.0，平均分：${avg}\n核心课程：${courseText || '暂无'}\n\n项目经历\n${projectText || '暂无'}\n\n荣誉奖项\n${achievementText || '暂无'}`;
}
