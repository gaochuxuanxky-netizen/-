import React from 'react';
import ReactDOM from 'react-dom/client';
import { Award, BarChart3, BookOpen, BriefcaseBusiness, Download, GraduationCap, Plus, Sparkles, Target, Trash2 } from 'lucide-react';
import { buildResume, calculateGpa, defaultData, evaluateAbilities, generateSuggestions, goalLabels } from './lib/smartpath';
import { Achievement, Course, GoalType, Project, SmartPathData } from './types/smartpath';
import './styles.css';

const storageKey = 'smartpath-platform-data';

function loadData(): SmartPathData {
  const saved = localStorage.getItem(storageKey);
  if (!saved) return defaultData;

  try {
    return JSON.parse(saved) as SmartPathData;
  } catch {
    return defaultData;
  }
}

function App() {
  const [data, setData] = React.useState<SmartPathData>(loadData);
  const [resumeVisible, setResumeVisible] = React.useState(false);

  React.useEffect(() => {
    localStorage.setItem(storageKey, JSON.stringify(data));
  }, [data]);

  const abilities = evaluateAbilities(data.courses, data.projects, data.achievements);
  const suggestions = generateSuggestions(data);
  const resume = buildResume(data);

  const updateProfile = (field: keyof SmartPathData['profile'], value: string) => {
    setData((current) => ({
      ...current,
      profile: { ...current.profile, [field]: value },
    }));
  };

  const addCourse = () => {
    const course: Course = { id: crypto.randomUUID(), name: '新课程', credit: 2, score: 80, category: '专业课程' };
    setData((current) => ({ ...current, courses: [...current.courses, course] }));
  };

  const updateCourse = (id: string, field: keyof Course, value: string | number) => {
    setData((current) => ({
      ...current,
      courses: current.courses.map((course) => (course.id === id ? { ...course, [field]: value } : course)),
    }));
  };

  const removeCourse = (id: string) => {
    setData((current) => ({ ...current, courses: current.courses.filter((course) => course.id !== id) }));
  };

  const addProject = () => {
    const project: Project = {
      id: crypto.randomUUID(),
      name: '新项目',
      role: '成员',
      type: '实践项目',
      description: '描述项目背景、个人贡献与结果。',
      tags: ['待补充'],
      impact: 3,
    };
    setData((current) => ({ ...current, projects: [...current.projects, project] }));
  };

  const updateProject = (id: string, field: keyof Project, value: string | number | string[]) => {
    setData((current) => ({
      ...current,
      projects: current.projects.map((project) => (project.id === id ? { ...project, [field]: value } : project)),
    }));
  };

  const removeProject = (id: string) => {
    setData((current) => ({ ...current, projects: current.projects.filter((project) => project.id !== id) }));
  };

  const addAchievement = () => {
    const achievement: Achievement = {
      id: crypto.randomUUID(),
      name: '新荣誉',
      level: '校级',
      date: '2026-05',
      description: '补充获奖背景与个人贡献。',
    };
    setData((current) => ({ ...current, achievements: [...current.achievements, achievement] }));
  };

  const updateAchievement = (id: string, field: keyof Achievement, value: string) => {
    setData((current) => ({
      ...current,
      achievements: current.achievements.map((achievement) => (achievement.id === id ? { ...achievement, [field]: value } : achievement)),
    }));
  };

  const removeAchievement = (id: string) => {
    setData((current) => ({ ...current, achievements: current.achievements.filter((achievement) => achievement.id !== id) }));
  };

  const downloadResume = () => {
    const blob = new Blob([resume], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${data.profile.name || 'SmartPath'}-智能简历.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <main>
      <section className="hero">
        <div>
          <p className="eyebrow"><Sparkles size={16} /> SmartPath Platform</p>
          <h1>大学生智能成长规划系统</h1>
          <p className="hero-text">统一管理课程、项目、竞赛荣誉与发展目标，自动计算 GPA、评估能力画像，并生成个性化成长建议与简历内容。</p>
          <div className="hero-actions">
            <button onClick={() => setResumeVisible(true)}><Download size={18} />生成简历</button>
            <button className="secondary" onClick={() => setData(defaultData)}>恢复示例数据</button>
          </div>
        </div>
        <div className="score-card">
          <span>综合能力评分</span>
          <strong>{abilities.overall}</strong>
          <p>目标：{goalLabels[data.profile.target]}</p>
        </div>
      </section>

      <section className="grid stats">
        <Stat icon={<GraduationCap />} label="GPA" value={calculateGpa(data.courses).toString()} />
        <Stat icon={<BookOpen />} label="课程数量" value={data.courses.length.toString()} />
        <Stat icon={<BriefcaseBusiness />} label="项目经历" value={data.projects.length.toString()} />
        <Stat icon={<Award />} label="荣誉奖项" value={data.achievements.length.toString()} />
      </section>

      <section className="panel profile-panel">
        <div className="section-title"><Target /> <h2>个人目标档案</h2></div>
        <div className="form-grid">
          <Input label="姓名" value={data.profile.name} onChange={(value) => updateProfile('name', value)} />
          <Input label="学校" value={data.profile.school} onChange={(value) => updateProfile('school', value)} />
          <Input label="专业" value={data.profile.major} onChange={(value) => updateProfile('major', value)} />
          <Input label="年级" value={data.profile.grade} onChange={(value) => updateProfile('grade', value)} />
          <label>
            发展目标
            <select value={data.profile.target} onChange={(event) => updateProfile('target', event.target.value as GoalType)}>
              {Object.entries(goalLabels).map(([key, label]) => <option key={key} value={key}>{label}</option>)}
            </select>
          </label>
        </div>
      </section>

      <section className="workspace">
        <DataPanel title="课程与成绩管理" icon={<BookOpen />} action="新增课程" onAdd={addCourse}>
          {data.courses.map((course) => (
            <article className="item-row" key={course.id}>
              <Input label="课程名称" value={course.name} onChange={(value) => updateCourse(course.id, 'name', value)} />
              <Input label="类别" value={course.category} onChange={(value) => updateCourse(course.id, 'category', value)} />
              <Input label="学分" type="number" value={course.credit} onChange={(value) => updateCourse(course.id, 'credit', Number(value))} />
              <Input label="成绩" type="number" value={course.score} onChange={(value) => updateCourse(course.id, 'score', Number(value))} />
              <button className="icon-button" onClick={() => removeCourse(course.id)} aria-label="删除课程"><Trash2 size={18} /></button>
            </article>
          ))}
        </DataPanel>

        <DataPanel title="项目与实践经历" icon={<BriefcaseBusiness />} action="新增项目" onAdd={addProject}>
          {data.projects.map((project) => (
            <article className="card-form" key={project.id}>
              <div className="item-row compact">
                <Input label="项目名称" value={project.name} onChange={(value) => updateProject(project.id, 'name', value)} />
                <Input label="个人角色" value={project.role} onChange={(value) => updateProject(project.id, 'role', value)} />
                <Input label="项目类型" value={project.type} onChange={(value) => updateProject(project.id, 'type', value)} />
                <Input label="影响力" type="number" value={project.impact} onChange={(value) => updateProject(project.id, 'impact', Number(value))} />
                <button className="icon-button" onClick={() => removeProject(project.id)} aria-label="删除项目"><Trash2 size={18} /></button>
              </div>
              <textarea value={project.description} onChange={(event) => updateProject(project.id, 'description', event.target.value)} />
              <Input label="标签（用逗号分隔）" value={project.tags.join(', ')} onChange={(value) => updateProject(project.id, 'tags', value.split(',').map((tag) => tag.trim()).filter(Boolean))} />
            </article>
          ))}
        </DataPanel>

        <DataPanel title="荣誉与奖项记录" icon={<Award />} action="新增荣誉" onAdd={addAchievement}>
          {data.achievements.map((achievement) => (
            <article className="card-form" key={achievement.id}>
              <div className="item-row compact">
                <Input label="名称" value={achievement.name} onChange={(value) => updateAchievement(achievement.id, 'name', value)} />
                <Input label="等级" value={achievement.level} onChange={(value) => updateAchievement(achievement.id, 'level', value)} />
                <Input label="时间" value={achievement.date} onChange={(value) => updateAchievement(achievement.id, 'date', value)} />
                <button className="icon-button" onClick={() => removeAchievement(achievement.id)} aria-label="删除荣誉"><Trash2 size={18} /></button>
              </div>
              <textarea value={achievement.description} onChange={(event) => updateAchievement(achievement.id, 'description', event.target.value)} />
            </article>
          ))}
        </DataPanel>
      </section>

      <section className="analysis-layout">
        <div className="panel">
          <div className="section-title"><BarChart3 /> <h2>智能能力分析</h2></div>
          {Object.entries({ 学业能力: abilities.academic, 实践能力: abilities.practice, 创新能力: abilities.innovation, 荣誉积累: abilities.honor }).map(([label, value]) => (
            <div className="meter" key={label}>
              <span>{label}</span>
              <div><i style={{ width: `${value}%` }} /></div>
              <b>{value}</b>
            </div>
          ))}
        </div>
        <div className="panel">
          <div className="section-title"><Sparkles /> <h2>发展建议</h2></div>
          <div className="suggestions">
            {suggestions.map((suggestion) => (
              <article key={suggestion.title}>
                <span className={`priority p-${suggestion.priority}`}>{suggestion.priority}优先级</span>
                <h3>{suggestion.title}</h3>
                <p>{suggestion.detail}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      {resumeVisible && (
        <div className="modal" role="dialog" aria-modal="true">
          <div className="modal-card">
            <div className="modal-head">
              <h2>结构化个人简历</h2>
              <button className="secondary" onClick={() => setResumeVisible(false)}>关闭</button>
            </div>
            <pre>{resume}</pre>
            <button onClick={downloadResume}><Download size={18} />下载 TXT 简历</button>
          </div>
        </div>
      )}
    </main>
  );
}

function Stat({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return <div className="stat-card">{icon}<span>{label}</span><strong>{value}</strong></div>;
}

function Input({ label, value, onChange, type = 'text' }: { label: string; value: string | number; onChange: (value: string) => void; type?: string }) {
  return <label>{label}<input type={type} value={value} onChange={(event) => onChange(event.target.value)} /></label>;
}

function DataPanel({ title, icon, action, onAdd, children }: { title: string; icon: React.ReactNode; action: string; onAdd: () => void; children: React.ReactNode }) {
  return (
    <section className="panel data-panel">
      <div className="panel-head">
        <div className="section-title">{icon}<h2>{title}</h2></div>
        <button className="small" onClick={onAdd}><Plus size={16} />{action}</button>
      </div>
      <div className="data-list">{children}</div>
    </section>
  );
}

ReactDOM.createRoot(document.getElementById('root')!).render(<App />);
